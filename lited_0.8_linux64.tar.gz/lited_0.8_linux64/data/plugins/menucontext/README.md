# menucontext
Based on lite-contextmenu by takase1121 https://github.com/takase1121/lite-contextmenu
Adds context menu to lited.

### TreeView integration
- ~~you will need to install [lite-fsutils](https://github.com/takase1121/lite-fsutils) for it to work~~
- ~~replace `treeview.lua` with the one in the repo~~
