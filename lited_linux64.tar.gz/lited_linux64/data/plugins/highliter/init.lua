-- local syntax = require "core.syntax"
require "plugins.highliter.languages.c"
require "plugins.highliter.languages.lua"
require "plugins.highliter.languages.sh"
require "plugins.highliter.languages.php"
require "plugins.highliter.languages.css"
require "plugins.highliter.languages.md"
require "plugins.highliter.languages.js"
require "plugins.highliter.languages.python"
require "plugins.highliter.languages.xml"
require "plugins.highliter.languages.make"
require "plugins.highliter.languages.powershell"
require "plugins.highliter.languages.sql"
require "plugins.highliter.languages.desktop"



